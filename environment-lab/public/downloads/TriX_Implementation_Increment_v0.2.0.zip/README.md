# TriX Environment Lab 0.2.0

A private environment planner and experimental pure CPU reference implementation based on **TriX Design and Implementation Standard v0.2**. TriX uses she/her pronouns. The interface, contracts and implementation documentation are in English.

## Implemented

- Hardware/OS/ABI/backend compatibility diagnostics, with separate group and whole-scenario assessment.
- Physical/process ISA, native/guest/emulated execution, devices per node, CPU sockets, NUMA, PCIe, link declarations and separate memory reservations.
- Per-task workload, placement, dependency and input/output contracts; cycles, missing references and incompatible contracts block generation.
- Versioned v2 JSON with v1 migration; recoverable browser-local persistence, independent comparison snapshots, JSON/YAML/Markdown exports and qualification checklists.
- Analytical memory, user-declared whole-node cost and energy estimates. Missing inputs remain unknown.
- Experimental typed pure CPU plans, a ReferencePlanBuilder SDK, a verifier, six bounded operations, no effects and a Node CLI with explicit checkpoint output.
- Existing About TriX, themes, deterministic local commands, proposal review/undo and proposed Agent workspace retained from the latest private Site source.

This is not the complete TriX language, compiler, production runtime, model executor or hardware qualification service. Version strings remain declarations. Vendor profiles, performance, numerical model correctness, distributed operation, authority enforcement and failure recovery require real adapters and evidence. A declarative adapter manifest does not install code or grant authority.

## Development

No third-party runtime dependencies are required.

```sh
npm test
npm run check
node scripts/generate-contracts.mjs
```

The optional Python JSON Schema validator used during development is not an application dependency.

- `dist/model.mjs`: v2 planning contract, migration, workflows, estimates and qualifications.
- `dist/compatibility.mjs`: conservative platform/backend rules retained from the preceding release.
- `dist/storage.mjs`: recoverable scenario and comparison persistence.
- `dist/reference-plan.mjs`: verifier and pure CPU execution subset.
- `dist/adapters.mjs`: declarative extension profile validation.
- `dist/agents.mjs`: existing bounded deterministic local command tools.
- `dist/contracts/`: JSON Schema contracts, generated from the contract source.
- `docs/implementation-increment-v0.2.md`: authority, contracts, acceptance mapping, limits and next work.
- `docs/verification.md`: executed checks and unexecuted qualifications.

## Run the CPU reference

Export the example through **Plan verifier → Download plan**, then run:

```sh
node scripts/run-reference-plan.mjs TriX_Reference_CPU_Plan.json
node scripts/run-reference-plan.mjs TriX_Reference_CPU_Plan.json --state cpu-state.json
```

The CLI reads the supplied plan file. `--state` explicitly authorizes writing the named checkpoint plus a lock and temporary sibling file. It refuses to overwrite the plan with state. It serializes access with an exclusive lock and validates a completed pure result before reuse. A different plan, malformed state or mismatched result is refused. A stale lock after process loss requires reconciliation. The checkpoint is an experimental whole-plan result; it does not establish distributed recovery or power-loss durability.

The plan language cannot access the filesystem, process APIs, credentials, network, model providers or executable plugins. Only the CLI wrapper performs the explicitly requested input/checkpoint I/O.

## Publication and privacy

Preserve the existing Site project identity and owner-only audience. Public access requires the user's explicit approval. Hosting enforces access; UI badges are informational. Browser storage is local to the browser, not cloud synchronization. JSON is the portable copy. No third-party analytics or provider credentials are present.
